﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _13.BinaryToDecimalNumber
{
    class BinaryToDecimalNumber
    {
        static void Main(string[] args)
        {
            // 13. Using loops write a program that converts a binary integer number to its decimal form.
            //   The input is entered as string. The output should be a variable of type long.
            //   Do not use the built-in .NET functionality.
            
            Console.Write("Enter an integer number N: ");
            string binaryNumber = Console.ReadLine();
            long result;
        }
    }
}
