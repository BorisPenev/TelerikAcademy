﻿

namespace _10.EmployeeData
{
    public enum Sex
    {
        Male,
        Female
    }
}
