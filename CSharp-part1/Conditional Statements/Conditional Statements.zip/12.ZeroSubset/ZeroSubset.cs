﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _12.ZeroSubset
{
    class ZeroSubset
    {
        static void Main()
        {
           // 12. We are given 5 integer numbers. Write a program that finds all subsets of these numbers whose sum is 0.
           //     Assume that repeating the same subset several times is not a problem.
        }
    }
}
