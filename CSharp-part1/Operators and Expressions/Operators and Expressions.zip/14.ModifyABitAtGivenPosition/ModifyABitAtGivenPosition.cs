﻿using _12.ExtractBitFromInteger;
using System;

namespace _14.ModifyABitAtGivenPosition
{
    class ModifyABitAtGivenPosition
    {
        static void Main()
        {
            // 14. Change the value of a bit for a given number N, position P and value V (0 or 1).
            // For example: n = 35, p = 5, v = 0  result: n = 3

            Bit bit = new Bit();
            bit.PrintNumberWithReplacedBit();
        }
    }
}
