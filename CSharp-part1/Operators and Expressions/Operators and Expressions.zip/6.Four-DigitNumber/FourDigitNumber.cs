﻿using System;

namespace _6.Four_DigitNumber
{
    class FourDigitNumber
    {
        static void Main(string[] args)
        {
            OperationsOnFourDigitNumber operations = new OperationsOnFourDigitNumber();
        }
    }
}
