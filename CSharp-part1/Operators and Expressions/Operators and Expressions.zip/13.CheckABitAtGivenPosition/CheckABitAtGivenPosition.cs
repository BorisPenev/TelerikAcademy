﻿using _12.ExtractBitFromInteger;
using System;
namespace _13.CheckABitAtGivenPosition
{
    class CheckABitAtGivenPosition
    {
        static void Main()
        { 
            // 13. Check if bit is 1 for a given number N and position P and return true or false.
            Bit printBitAtPositionP = new Bit();
            printBitAtPositionP.IsBitOne();
        }
    }
}
