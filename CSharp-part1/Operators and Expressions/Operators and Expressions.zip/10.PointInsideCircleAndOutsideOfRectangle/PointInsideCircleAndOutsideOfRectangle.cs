﻿using _7.PointInACircle;
using System;

namespace _10.PointInsideCircleAndOutsideOfRectangle
{
    class PointInsideCircleAndOutsideOfRectangle
    {
        static void Main()
        {
            Circle.IsPointInCircleAndOutsideOfRectangle();
        }
    }
}
