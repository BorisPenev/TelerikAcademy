﻿using System;

namespace _12.ExtractBitFromInteger
{
    class ExtractBitFromInteger
    { 
        static void Main()
        {
            //12. Print the bit (0 or 1) for a given number N and position P.
            Bit printBitAtPositionP = new Bit();
        }
    }
}
