﻿using System;

namespace _7.PointInACircle
{
    class PointInACircle
    {
        static void Main()
        {
            Circle.IsPointInCircle();
        }
    }
}
